'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# Soal 1 : Kategori usia
umur=(int(input()))
if(umur>=18) :
    print("Anda dewasa")
elif(umur>=13 and umur<18) :
    print("Anda remaja")
elif(umur<13) :
    print("Anda anak-anak")

# Soal 2 : Megurutkan angka
a, b, c = map(int, input().split())
if a > b:
    a, b = b, a
if b > c:
    b, c = c, b
if a > b:
    a, b = b, a
print(a, b, c)

# Soal 3 : Menentukan angka terbesar
a, b, c = map(int,input().split())
if a>=b and a>=c :
    print(a)
elif b>=a and b>=c :
    print(b)
elif c>=a and c>=b :
    print(c)

# Soal 4 : Menentukan bilangan prima
bil = int(input())
 
pembagi = 0
 
if bil > 1:
    for i in range(2, bil):
        if (bil % i) == 0:
            pembagi += 1
 
if pembagi == 0 and bil > 1:
    print("Bilangan prima")
else:
    print("Bukan bilangan prima")

# Soal 5 : Menentukan palindrom
kata = input('')
temp = ''
for i in range(len(kata)): 
    temp+=kata[i]
if(kata == temp):
    print("Palindrom")
else:
    print("Bukan palindrom")
